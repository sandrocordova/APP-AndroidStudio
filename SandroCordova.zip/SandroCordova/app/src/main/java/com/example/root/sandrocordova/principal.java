package com.example.root.sandrocordova;

import android.app.Dialog;
import android.content.Intent;
import android.net.Uri;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class principal extends AppCompatActivity implements FrgUno.OnFragmentInteractionListener {

    double total;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.opcionFragmento:
                FrgUno frgUno = new FrgUno();
                FragmentTransaction transactionUno = getSupportFragmentManager().beginTransaction();
                transactionUno.replace(R.id.contenedor, frgUno);
                transactionUno.commit();
                break;

            case R.id.opcionDialogo:
                Dialog dlgCalcular = new Dialog(principal.this);
                dlgCalcular.setContentView(R.layout.dialogo);

                final EditText cajaHoras = (EditText) dlgCalcular.findViewById(R.id.dlghoras);

                final EditText cajaPrecio = (EditText) dlgCalcular.findViewById(R.id.dlgprecio);
                final double horas = Integer.parseInt(cajaHoras.getText().toString());
                final double precio = Integer.parseInt(cajaPrecio.getText().toString());

                if (horas<= 40){
                    total = horas*precio;

                } else {
                    final double suma = horas-40;
                    final double precioaux = precio*1.5;
                    final double auxtotal = precio * horas;
                    total = auxtotal+(suma * precioaux);
                }

                if (total <= 200){
                    total = total;
                }else {
                    final double aux1 = total-200;
                    final double aux2 = aux1*0.10;
                    total = total+aux2;

                }

                Button botonCalcular = (Button) dlgCalcular.findViewById(R.id.btnCalcular);

                botonCalcular.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        Toast.makeText(principal.this,"Hola" +total , Toast.LENGTH_SHORT).show();
                    }
            });
                //el dlg se parece a un toast y por eso necesita un show, no estoy seguro si era con el toast :V
                dlgCalcular.show();
                break;


        }
        return true;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main, menu);
        return true;
    }


    @Override
    public void onFragmentInteraction(Uri uri) {

    }
}
